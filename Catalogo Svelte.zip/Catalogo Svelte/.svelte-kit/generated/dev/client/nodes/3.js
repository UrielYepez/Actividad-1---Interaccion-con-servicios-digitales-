import * as universal from "../../../../../src/routes/producto/[id]/+page.js";
export { universal };
export { default as component } from "../../../../../src/routes/producto/[id]/+page.svelte";